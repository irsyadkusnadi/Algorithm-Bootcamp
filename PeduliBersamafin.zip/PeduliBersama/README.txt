Jelaskan apliaksi : Aplikasi ini digunakan untuk mendata peserta vaksinasi Covid 19 di Jakarta. 
Pendataan meliputi nama, umur, jenis vaksin yang digunakan, periode vaksin, dan data terjangkit. 
Periode vaksin digunakan untuk menandai sudah berapa kali peserta tersebut melakukan vaksin. 
data terjangkit digunakan untuk mengetahui apakah peserta tersebut sudah pernah terjangkit covid-19 atau belum. 
Tidak hanya mendata, tapi aplikasi ini juga dapat mengecek status vaksinasi seseorang berdasarkan data yang ada

alasan: Kondisi pandemi covid-19 di Indonesia yang sudah mulai membaik merupakan peranan besar dari vaksin yang digunakan.
 Karena itu, kami berinisiatif untuk mendata status vaksinasi di area Jakarta agar bisa diolah lebih lanjut.